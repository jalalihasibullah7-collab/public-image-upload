const formidable = require("formidable");

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  const form = formidable({ multiples: false });
  try {
    const [fields, files] = await form.parse(req);
    const file = Array.isArray(files.file) ? files.file[0] : files.file;

    if (!file || !file.filepath) {
      return res.status(400).json({ success: false, error: "No image uploaded" });
    }

    const fs = require("fs");
    const FormData = require("form-data");
    const https = require("https");

    const formData = new FormData();
    formData.append("file", fs.createReadStream(file.filepath), {
      filename: file.originalFilename || "image.jpg",
      contentType: file.mimetype || "application/octet-stream"
    });

    const result = await new Promise((resolve, reject) => {
      const request = https.request({
        hostname: "file.io",
        path: "/?expires=1w",
        method: "POST",
        headers: formData.getHeaders()
      }, response => {
        let body = "";
        response.on("data", chunk => body += chunk);
        response.on("end", () => {
          try {
            resolve({ status: response.statusCode, data: JSON.parse(body) });
          } catch {
            reject(new Error("Invalid upload response"));
          }
        });
      });
      request.on("error", reject);
      formData.pipe(request);
    });

    if (result.status < 200 || result.status >= 300 || !result.data.link) {
      return res.status(502).json({
        success: false,
        error: result.data?.message || "Image host rejected the upload"
      });
    }

    return res.status(200).json({
      success: true,
      link: result.data.link,
      expires: result.data.expires || result.data.expiry || "1 week"
    });
  } catch (e) {
    return res.status(500).json({ success: false, error: e.message || "Upload failed" });
  }
};
